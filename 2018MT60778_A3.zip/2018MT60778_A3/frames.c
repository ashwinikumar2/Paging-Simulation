#include <stdio.h>
#include <stdlib.h>
#include<string.h> 
struct Node { 
    int dirty,valid;
    char* virtual_address; 
} block; 

int main(int argc, char* argv[])
{
	
	char* filename=argv[1];
	int number_of_frames=atoi(argv[2]);
	char* strategy=argv[3];

	int available_pages=number_of_frames;
	// printf("filename= %s frames= %d strategy= %s\n",filename,number_of_frames,strategy);
	FILE *fptr;
	char * line = NULL;
    size_t len = 0;
    ssize_t read;
	fptr = fopen(filename, "r");
    if (fptr == NULL)
    {
        printf("Cannot open file \n");
        exit(0);
    }

    struct Node page_table[number_of_frames];
    
    for(int i=0;i<number_of_frames;i++)
    {

    	struct Node node1;
        node1.dirty=0;
        node1.valid=0;
        node1.virtual_address=NULL;
        page_table[i]=node1;
    }
    struct Node page_table1[number_of_frames];
    
		    for(int i=0;i<number_of_frames;i++)
		    {

		    	struct Node node1;
		        node1.dirty=0;
		        node1.valid=0;
		        node1.virtual_address=NULL;
		        page_table1[i]=node1;
		    }
    int* index=malloc(number_of_frames*sizeof(int));
	for(int i=0;i<number_of_frames;i++)
	{
		index[i]=-1;
	}
    // char command = fgetc(fptr);
    // while (command != EOF)
    // {
    //     printf ("%d", command[0]);
    //     command = fgetc(fptr);

    // }
 //    for(int i=0;i<number_of_frames;i++)
	// {
	// 	// if(page_table[i]->virtual_address !=NULL)
	// 	printf("(%d, %d, %s) ",page_table[i].dirty,page_table[i].valid,page_table[i].virtual_address);
	// }
    int filled_frames=0;
    int line_no=0;
    int memory_accesses=0,misses=0,hits=0,drops=0,writes=0;
    srand(5635);
  	while ((read = getline(&line, &len, fptr)) != -1) {
  		memory_accesses++;
  		line_no++;
  		// printf("line_no= %d\n",line_no);

        // printf("Retrieved line of length %zu:\n", read);
        // printf("type= %c\n",line[12]);		//how to know whether it is read or write?
        // printf("========================STARTING=======================\n\n");
        // printf("Command is %s\n", line);
        char* toke1=malloc(100*sizeof(char));
        char* toke=strtok(line," ");			//taking reference from before and updates all values
        strcpy(toke1, toke);
        char* toke2=malloc(sizeof(char));
        char* toke3=strtok(NULL," ");
        strcpy(toke2, toke3);
        char* s=malloc(strlen(toke1)*sizeof(char));
    	for(int k=0;k<strlen(toke1)-3;k++)
    	{
    		s[k]=toke1[k];
    	}
    	strcpy(toke1,s);
    	// printf("toke1= %s\n",toke1);
     //    if(strcmp("0x4000b34b",toke1)==0){
  			// printf("reached\n");
  			// printf("toke1= %s page_table[0]= %s\n",toke1,page_table[0].virtual_address);
     //    }
        // printf("token= %s toke2= %s\n",toke,toke2);

        // fifo(number_of_frames, page_table,toke1,toke2, line);
        // printf("strcpy(strategy,FIFO)= %d\n",strcpy(strategy,"FIFO"));
        if(strcmp(strategy,"FIFO")==0)
        { 
		    int already_present=0,found_index=-1,already_present_page=0;
			for (int i=0;i<number_of_frames;i++)
		    {
		    	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0) {
		    		already_present_page=1,already_present=1;
		    		found_index=i;
		    		if(toke2[0]=='R'){
					}

		        	else{
		        		page_table[i].dirty=1;
		        	}
		        	break;
		    	}
		    }
		    if(already_present==0){
		    		misses++;
		    	
		    	// printf("s= %s and toke1= %s\n",s,toke1);
		    	if(page_table[0].virtual_address!=NULL )
		    	{
		    		if(strcmp(toke1,page_table[0].virtual_address)!=0)
		    		{
			    		if(page_table[0].dirty==0){
			    			drops++;
			    			if(argc>4)
			    				printf("Page %s was read from disk, page %s was dropped (it was not dirty).\n",toke1,page_table[0].virtual_address);
			    			
			    		}
			    		else if(page_table[0].dirty==1){
			    			writes++;
			    			if(argc>4)
			    				printf("Page %s was read from disk, page %s was written to the disk.\n",toke1,page_table[0].virtual_address);
			    			
			    		}
		    		}
		    	}

		    }

		 //    printf("after checking for presence: \n");
		 //    for(int i=0;i<number_of_frames;i++)
			// {
			// 	// if(page_table[i]->virtual_address !=NULL)
			// 	printf("(%d, %d, %s) ",page_table[i].dirty,page_table[i].valid,page_table[i].virtual_address);
			// }
			// printf("\n");
			if(already_present==0)
			{

			    for(int i=0;i<found_index;i++)
			    {
			    	// printf("i= %d\n",i);
			    	page_table1[i].dirty=page_table[i].dirty;
			    	page_table1[i].valid=page_table[i].valid;
			    	page_table1[i].virtual_address=page_table[i].virtual_address;
			    }
			    for(int i=found_index+1;i<number_of_frames;i++)
			    {
			    	// printf("i= %d\n",i);
			    	page_table1[i-1]=page_table[i];
			    }
			    page_table1[number_of_frames-1].dirty=0;	
			    // printf("before page_table1[last].dirty= %d\n",page_table[number_of_frames-1].dirty);
		    	
			    if(already_present==1){
			    	if(toke2[0]=='R'){
			    		// printf("present already and a read\n");
	        		}
		        	else{
		        		// printf("present already and a write\n");
		        		page_table1[number_of_frames-1].dirty=1;
		        	}
		    	}
		    	else
		    	{
		    		if(toke2[0]=='R'){

		        		page_table1[number_of_frames-1].dirty=0;
		        		// printf("its read\n");
	        		}
		        	else{
		        		page_table1[number_of_frames-1].dirty=1;
		        	}
		    	}
		    	// printf("finally page_table1[last].dirty= %d\n",page_table[number_of_frames-1].dirty);
		    	page_table1[number_of_frames-1].valid=0;
		        page_table1[number_of_frames-1].virtual_address=toke1;

			    for(int i=0;i<number_of_frames;i++)
			    {
		    		page_table[i].dirty=page_table1[i].dirty;
		    		page_table[i].virtual_address=page_table1[i].virtual_address;
			    }
			}
		 //    printf("misses= %d drops= %d and writes= %d \n",misses,drops,writes);
		 //    for(int i=0;i<number_of_frames;i++)
			// {
			// 	// if(page_table[i]->virtual_address !=NULL)
			// 	printf("(%d, %d, %s) ",page_table1[i].dirty,page_table1[i].valid,page_table1[i].virtual_address);
			// }
			// printf("\n\n");
			

        }

        if(strcmp(strategy,"RANDOM")==0)
        {
      //   	if(strcmp("0x4000c34b",toke1)==0)
		    //     	{
		    //     		printf("before:\n");
		    //     		for(int i=0;i<number_of_frames;i++)
						// {
						// 	// if(page_table[i]->virtual_address !=NULL)
						// 	printf("(%d, %d, %s) ",page_table[i].dirty,page_table[i].valid,page_table[i].virtual_address);
						// }
						// printf("\n");
		    //     	}
        	int already_present=0,found_index=-1,already_present_page=0;
			for (int i=0;i<number_of_frames;i++)
		    {
		    	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0) {
		    		already_present_page=1,already_present=1;
		    		found_index=i;
		    		if(toke2[0]=='R'){
					}

		        	else{
		        		page_table[i].dirty=1;
		        	}
		        	break;
		    	}
		    }

		    if(already_present_page==0){

		    
		    	misses++;
		    	

		    }
			// if(strcmp("0x4000b345",toke1)==0)
		 //    {
		 //    	printf("page_table[0]= %s page_table[1]= %s\n",page_table[0].virtual_address,page_table[1].virtual_address );
		 //    	printf("reached found_index= %d\n",found_index);
		 //    }

		    if(found_index==-1)
		    {
		    	for(int i=0;i<number_of_frames;i++)
		    	{
		    		if(page_table[i].virtual_address==NULL){
		    			found_index=i;
		    			page_table[i].virtual_address=toke1;
		    			if(toke2[0]=='R'){
		    				page_table[i].dirty=0;
						}

			        	else
			        		page_table[i].dirty=1;
		    			break;
		    		}

		    	}

		    	// if(strcmp("0x4000b345",toke1)==0)
			    // {
			    // 	printf("page_table[0]= %s page_table[1]= %s\n",page_table[0].virtual_address,page_table[1].virtual_address );
			    // 	printf("reached found_index= %d\n",found_index);
			    // }
		    	if(found_index==-1 )	//no hit
		    	{
		    		int index=rand()%number_of_frames;
		    		// printf("for random index= %d\n",index);

		    		if(page_table[index].virtual_address!=NULL)
			    	{
			    		// char* s1=malloc(strlen(page_table[index].virtual_address)*sizeof(char));
				    	// for(int k=0;k<strlen(page_table[index].virtual_address)-3;k++)
				    	// {
				    	// 	s1[k]=page_table[index].virtual_address[k];
				    	// }
				    	// printf("s1= %s and page_table[0].virtual_address= %s\n",s1,page_table[0].virtual_address);
			    		if(strcmp(toke1,page_table[index].virtual_address)!=0)
			    		{
				    		if(page_table[index].dirty==0){
				    			drops++;
				    			if(argc>4)
				    				printf("Page %s was read from disk, page %s was dropped (it was not dirty).\n",toke1,page_table[index].virtual_address);
				    			
				    		}
				    		else if(page_table[index].dirty==1){
				    			writes++;
				    			if(argc>4)
				    				printf("Page %s was read from disk, page %s was written to the disk.\n",toke1,page_table[index].virtual_address);
				    			
				    		}
			    		}
			    	}

		    		page_table[index].virtual_address=toke1;
	    			if(toke2[0]=='R'){
	    				page_table[index].dirty=0;
					}

		        	else
		        		page_table[index].dirty=1;

		    //     	if(strcmp("0x4000c34b",toke1)==0)
		    //     	{
		    //     		for(int i=0;i<number_of_frames;i++)
						// {
						// 	// if(page_table[i]->virtual_address !=NULL)
						// 	printf("(%d, %d, %s) ",page_table[i].dirty,page_table[i].valid,page_table[i].virtual_address);
						// }
						// printf("\n");
		    //     	}
		    	}
		    }
        }
        if(strcmp(strategy,"LRU")==0)
        {
        	// printf("memory_accesses= %d\n",memory_accesses);
        	int already_present=0,found_index=-1,already_present_page=0;
			for (int i=0;i<number_of_frames;i++)
		    {
		    	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0) {
		    		already_present_page=1,already_present=1;
		    		found_index=i;
		    		index[i]=memory_accesses;
		    		if(toke2[0]=='R'){
					}

		        	else{
		        		page_table[i].dirty=1;
		        	}
		        	break;
		    	}
		    }

		    if(already_present_page==0){
		    	misses++;
		    }
			// for (int i=0;i<number_of_frames;i++)
		 //    {
		 //    	if(page_table[i].virtual_address!=NULL){
		 //    	char* s1=malloc(strlen(page_table[i].virtual_address)*sizeof(char));
		 //    	for(int k=0;k<strlen(page_table[i].virtual_address)-3;k++)
		 //    	{
		 //    		s1[k]=page_table[i].virtual_address[k];
		 //    	}
		 //    	if(strcmp(s,s1)==0)
		 //    		already_present_page=1;
		 //    	}
			// 	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0)
			// 	{
			// 		already_present =1;
			// 		hits++;
			// 		index[i]=memory_accesses;
			// 		// printf("ALREADY PRESENT PAGE\n");
			// 		if(toke2[0]=='R'){
			// 		}

		 //        	else
		 //        		page_table[i].dirty=1;
		 //        	// printf("page_table[%d].dirty= %d\n",i,page_table[i].dirty);
		 //        	filled_frames++;
		 //        	break;
			// 	}
		    	
		 //    }
		 //    if(already_present_page==0){
		 //    	misses++;
		    	

		 //    }
		    if(already_present==0)
		    {	
		    	double min=1.0/0.0;
		    	int lru=0;
		    	for(int i=0;i<number_of_frames;i++)
		    	{
		    		// printf("min = %f and index[%d]= %d\n",min,i,index[i] );
		    		if(min>index[i]){
		    			min=index[i];
		    			lru=i;
		    			if(index[i]==-1)
		    				break;
		    		}
		    	}
		    	// printf("min= %f lru= %d\n",min,lru);
		   
	    		index[lru]=memory_accesses;
	    		// if(page_table[lru].virtual_address!=NULL){
	    		// 	drops++;
	    		// }
	    		// misses++;

	    		if(page_table[lru].virtual_address!=NULL)
		    	{
		    		char* s1=malloc(strlen(page_table[lru].virtual_address)*sizeof(char));
			    	for(int k=0;k<strlen(page_table[lru].virtual_address)-3;k++)
			    	{
			    		s1[k]=page_table[lru].virtual_address[k];
			    	}
			    	// printf("s1= %s and page_table[0].virtual_address= %s\n",s1,page_table[0].virtual_address);
		    		if(strcmp(toke1,page_table[lru].virtual_address)!=0  )
		    		{
			    		if(page_table[lru].dirty==0){
			    			drops++;
			    			if(argc>4)
			    				printf("Page %s was read from disk, page %s was dropped (it was not dirty).\n",toke1,page_table[lru].virtual_address);
			    			
			    		}
			    		else if(page_table[lru].dirty==1){
			    			writes++;
			    			if(argc>4)
			    				printf("Page %s was read from disk, page %s was written to the disk.\n",toke1,page_table[lru].virtual_address);
			    			
			    		}
		    		}

		    		// if(page_table[lru].dirty==0)
		    		// 	drops++;
		    		// else if(page_table[lru].dirty==1)
		    		// 	writes++;
		    	}

	    		if(toke2[0]=='R'){
	    			// printf("command is read\n");
	        		page_table[lru].dirty=0;
	    		}
	        	else{
	        		// printf("command is write\n");
	        		page_table[lru].dirty=1;
	        	}
	        	page_table[lru].valid=0;
	        	page_table[lru].virtual_address =toke1;
			}

		 //    printf("memory_accesses= %d\n",memory_accesses);
		 //    printf("index array is:\n");
			// for(int i=0;i<number_of_frames;i++)
			// {
			// 	printf("index[%d]= %d\n",i,index[i] );
			// }	

        }
        if(strcmp(strategy,"CLOCK")==0)
        {
		 //    int already_present=0,found_index=-1,already_present_page=0;
		 //    char* s=malloc(strlen(toke1)*sizeof(char));
	  //   	for(int k=0;k<strlen(toke1)-3;k++)
	  //   	{
	  //   		s[k]=toke1[k];
	  //   	}
		 //    // if(toke2[0]=='W')
		 //    // 	writes++;
			// for (int i=0;i<number_of_frames;i++)
		 //    {
		 //    	if(page_table[i].virtual_address!=NULL){
		 //    	char* s1=malloc(strlen(page_table[i].virtual_address)*sizeof(char));
		 //    	for(int k=0;k<strlen(page_table[i].virtual_address)-3;k++)
		 //    	{
		 //    		s1[k]=page_table[i].virtual_address[k];
		 //    	}
		 //    	if(strcmp(s,s1)==0)
		 //    		already_present_page=1;
		 //    	}
			// 	// if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0 && page_table[i].valid==0)
			// 	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0)
			// 	{
			// 		already_present =1;
			// 		found_index=i;
			// 		hits++;
			// 		page_table[i].valid=1;
			// 		if(toke2[0]=='R'){
			// 		}

		 //        	else
		 //        		page_table[i].dirty=1;
		 //        	break;
			// 	}
		    	
		 //    }

		 //    if(already_present_page==0){
		 //    	// if(strcmp("0x4000b34b",toke1)==0)
		 //    	// 	printf("page not already_present_page=0 found_index= %d\n",found_index);
		 //    	misses++;
		    	

		 //    }
		    int already_present=0,found_index=-1,already_present_page=0;
			for (int i=0;i<number_of_frames;i++)
		    {
		    	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0) {
		    		already_present_page=1,already_present=1;
		    		found_index=i;
		    		index[i]=memory_accesses;
		    		page_table[i].valid=1;
		    		if(toke2[0]=='R'){
					}

		        	else{
		        		page_table[i].dirty=1;
		        	}
		        	break;
		    	}
		    }

		    if(already_present_page==0){
		    	misses++;
		    }
		    if(found_index==-1)
		    {
		    	for(int i=0;i<number_of_frames;i++)
		    	{
		    		if(page_table[i].valid==0){
		    			found_index=i;
		    			if(page_table[i].virtual_address!=NULL)
				    	{
				    		// char* s1=malloc(strlen(page_table[i].virtual_address)*sizeof(char));
					    	// for(int k=0;k<strlen(page_table[i].virtual_address)-3;k++)
					    	// {
					    	// 	s1[k]=page_table[i].virtual_address[k];
					    	// }
					    	// printf("s1= %s and page_table[0].virtual_address= %s\n",s1,page_table[0].virtual_address);
				    		if(strcmp(toke1,page_table[i].virtual_address)!=0  && already_present_page==0)
				    		{
					    		if(page_table[i].dirty==0){
					    			drops++;
					    			if(argc>4)
					    				printf("Page %s was read from disk, page %s was dropped (it was not dirty).\n",toke1,page_table[i].virtual_address);
					    			
					    		}
					    		else if(page_table[i].dirty==1){
					    			writes++;
					    			if(argc>4)
					    				printf("Page %s was read from disk, page %s was written to the disk.\n",toke1,page_table[i].virtual_address);
					    			
					    		}
				    		}
				    	}
		    			break;
		    		}

		    	}
		    }

		    if(found_index==-1 && page_table[0].virtual_address!=NULL)
	    	{
	    		// char* s1=malloc(strlen(page_table[0].virtual_address)*sizeof(char));
		    	// for(int k=0;k<strlen(page_table[0].virtual_address)-3;k++)
		    	// {
		    	// 	s1[k]=page_table[0].virtual_address[k];
		    	// }
		    	// printf("s1= %s and page_table[0].virtual_address= %s\n",s1,page_table[0].virtual_address);
	    		if(strcmp(toke1,page_table[0].virtual_address)!=0  )
	    		{
		    		if(page_table[0].dirty==0){
		    			drops++;
		    			if(argc>4)
		    				printf("Page %s was read from disk, page %s was dropped (it was not dirty).\n",toke1,page_table[0].virtual_address);
		    			
		    		}
		    		else if(page_table[0].dirty==1){
		    			writes++;
		    			if(argc>4)
		    				printf("Page %s was read from disk, page %s was written to the disk.\n",toke1,page_table[0].virtual_address);
		    			
		    		}
	    		}
	    		// if(page_table[0].dirty==0)
	    		// 	drops++;
	    		// else if(page_table[0].dirty==1)
	    		// 	writes++;
	    	}
	    	if(already_present==0){
			    if(page_table[0].virtual_address!=NULL)		//what if all have valid=1 and then still we are forcing them to be zero
			    {
			    	for(int i=0;i<number_of_frames;i++)
	        		{
	        			page_table[i].valid=0;
	        		}
			    }
			    for(int i=0;i<found_index;i++)
			    {
			    	page_table1[i].dirty=page_table[i].dirty;
			    	page_table1[i].valid=page_table[i].valid;
			    	page_table1[i].virtual_address=page_table[i].virtual_address;
			    }
			    for(int i=found_index+1;i<number_of_frames;i++)
			    {
			    	page_table1[i-1]=page_table[i];
			    }	
			    page_table1[number_of_frames-1].dirty=0;

			    page_table1[number_of_frames-1].valid=0;
		    	// printf("already_present= %d\n",already_present );
		    	if(already_present==1){
		    		page_table1[number_of_frames-1].valid=1;
		    		page_table1[number_of_frames-1].dirty=page_table[found_index].dirty;
		    	}	
			    if(already_present==1){
			    	if(toke2[0]=='R'){
	        		}
		        	else{
		        		page_table1[number_of_frames-1].dirty=1;
		        	}
		    	}
		    	else
		    	{
		    		if(toke2[0]=='R'){

		        		page_table1[number_of_frames-1].dirty=0;
		        		// printf("its read\n");
	        		}
		        	else{
		        		page_table1[number_of_frames-1].dirty=1;
		        	}
		    	}
		    	

		        page_table1[number_of_frames-1].virtual_address=toke1;

			    for(int i=0;i<number_of_frames;i++)
			    {
		    		page_table[i].dirty=page_table1[i].dirty;
		    		page_table[i].valid =page_table1[i].valid;
		    		page_table[i].virtual_address=page_table1[i].virtual_address;
			    }
			}
		 //    if(already_present==0)
		 //    {	
		 //    	printf("filled_frames= %d\n",filled_frames);
		 //    	if(page_table[filled_frames].valid==0){
        }

        if(strcmp(strategy,"OPT")==0)
        {
        	int already_present=0,found_index=-1,already_present_page=0;
			for (int i=0;i<number_of_frames;i++)
		    {
		    	if(page_table[i].virtual_address!=NULL && strcmp(page_table[i].virtual_address,toke1)==0) {
		    		already_present_page=1,already_present=1;
		    		found_index=i;
		    		index[i]=memory_accesses;
		    		page_table[i].valid=1;
		    		if(toke2[0]=='R'){
					}

		        	else{
		        		page_table[i].dirty=1;
		        	}
		        	break;
		    	}
		    }

		    if(already_present_page==0){
		    	misses++;
		    }

		    if(found_index==-1)
		    {
		    	for(int i=0;i<number_of_frames;i++)
		    	{
		    		if(page_table[i].virtual_address==NULL){
		    			found_index=i;
		    			break;
		    		}

		    	}

		    	if(found_index==-1)		//all filled but not hit so perform OPT
		    	{
				    // printf("next lines in the file are: \n");
		        	FILE *fptr1;
					char * line1 = NULL;
				    size_t len1 = 0;
				    ssize_t read1;
					fptr1 = fopen(filename, "r");
					int line_number=1;
					double min=1.0/0.0;
					int farthest_page_index=0;
					for(int i=0;i<number_of_frames;i++)
					{
						int match=-1;
						// printf("page_table[%d].virtual_address= %s\n",i,page_table[i].virtual_address);
						if(strcmp(page_table[i].virtual_address,toke1)!=0)
						while ((read1 = getline(&line1, &len1, fptr1)) != -1) 
						{
							if(line_number>memory_accesses)
							{
								// printf("line1= %s\n",line1);
								char* toke5=malloc(100*sizeof(char));
								
						        char* toke6=strtok(line1,"  ");			//taking reference from before and updates all values
						        strcpy(toke5, toke6);

						        char* s1=malloc((strlen(toke5)-3)*sizeof(char));
						    	for(int k=0;k<(strlen(toke5)-3);k++)
						    	{
						    		s1[k]=toke5[k];
						    	}
						    	strcpy(toke5,s1);
						        // printf("token= %s\n",toke5);
						        if(strcmp(toke5,page_table[i].virtual_address)==0)
						        {
						        	// printf("					matched toke5= %s\n",toke5);
						        	match=1;
						        	if(line_number- memory_accesses<min){
							        	min=line_number-memory_accesses;
							        	farthest_page_index=i;
						        	}
						        	break;
						        }
						        
						        
						        // break;
							}
							else
							{
								line_number++; 
							}
						}

						if(match==-1){
							min=0;
							farthest_page_index=i;
							break;
						}

						

					}

					if(page_table[farthest_page_index].virtual_address!=NULL)
			    	{
			    		// char* s1=malloc(strlen(page_table[farthest_page_index].virtual_address)*sizeof(char));
				    	// for(int k=0;k<strlen(page_table[farthest_page_index].virtual_address)-3;k++)
				    	// {
				    	// 	s1[k]=page_table[farthest_page_index].virtual_address[k];
				    	// }
				    	// printf("s1= %s and page_table[0].virtual_address= %s\n",s1,page_table[0].virtual_address);
			    		if(strcmp(toke1,page_table[farthest_page_index].virtual_address)!=0 )
			    		{
				    		if(page_table[farthest_page_index].dirty==0){
				    			drops++;
				    			if(argc>4)
				    				printf("Page %s was read from disk, page %s was dropped (it was not dirty).\n",toke1,page_table[farthest_page_index].virtual_address);
				    			
				    		}
				    		else if(page_table[farthest_page_index].dirty==1){
				    			writes++;
				    			if(argc>4)
				    				printf("Page %s was read from disk, page %s was written to the disk.\n",toke1,page_table[farthest_page_index].virtual_address);
				    			
				    		}
			    		}

			    		// if(page_table[farthest_page_index].dirty==0)
			    		// 	drops++;
			    		// else if(page_table[farthest_page_index].dirty==1)
			    		// 	writes++;
			    	}

					page_table[farthest_page_index].dirty=0;
		    		if(toke2[0]=='R'){

		        		page_table[farthest_page_index].dirty=0;
		        		// printf("its read\n");
	        		}
		        	else{
		        		// printf("its write\n");
		        		page_table[farthest_page_index].dirty=1;
		        		// printf("page_table[%d].dirty= %d\n",found_index,page_table[found_index].dirty);
		        	}

		        	page_table[farthest_page_index].virtual_address=toke1;
		    	}

		    	else
		    	{
		    		// printf("found_index= %d\n",found_index);
		    		page_table[found_index].dirty=0;
		    		if(toke2[0]=='R'){

		        		page_table[found_index].dirty=0;
		        		// printf("its read\n");
	        		}
		        	else{
		        		// printf("its write\n");
		        		page_table[found_index].dirty=1;
		        		// printf("page_table[%d].dirty= %d\n",found_index,page_table[found_index].dirty);
		        	}

		        	page_table[found_index].virtual_address=toke1;
		    	}
		    }


        	
        }
  //       printf("array becomes:\n");

	 //    for(int i=0;i<number_of_frames;i++)
		// {
		// 	// if(page_table[i]->virtual_address !=NULL)
		// 	printf("(%d, %d, %s) ",page_table[i].dirty,page_table[i].valid,page_table[i].virtual_address);
		// }

	 //    printf("\n\n");
  //       // printf("filled_frames= %d\n",filled_frames);
  //       printf("======================END==========================\n\n"); 
        // page_table[]
    }
    printf("Number of memory accesses: %d\n",memory_accesses);
	printf("Number of misses: %d\n",misses);
	printf("Number of writes: %d\n",writes);
	printf("Number of drops: %d\n",drops);

    // printf("memory_accesses= %d hits= %d misses= %d writes= %d drops= %d\n",memory_accesses,hits,misses,writes,drops );
    // for(int i=0;i<number_of_frames;i++)
    // {
    // 	// if(page_table[i]->virtual_address !=NULL)
    // 	// printf("page_table[%d]= (%d, %d, %p)\n",i,page_table[i]->dirty,page_table[i]->valid,page_table[i]->virtual_address);
    // }
    fclose(fptr);
	return 0;
}